/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frameberaksi2;

/**
 *
 * @author ASUS
 */
import javax.swing.*;

public class Frameberaksi2 extends JFrame {
    public Frameberaksi2(){
        super("frame beraksi 2");
        setSize(300,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public static void main(String[] args) {
       Frameberaksi2 frame = new Frameberaksi2();
    }
    
}
